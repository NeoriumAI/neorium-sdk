// DeFi Co-Pilot (Solana Only)
// MV3 Service Worker (module)
// Central message router + session state in chrome.storage.local

const DAPP_ORIGIN = "https://v0-de-fi-co-pilot-ui.vercel.app";

const MessageType = Object.freeze({
  GET_STATE: "GET_STATE",
  SET_PUBLIC_KEY: "SET_PUBLIC_KEY",
  DISCONNECT: "DISCONNECT",
  OPEN_SIDEPANEL: "OPEN_SIDEPANEL",
  IFRAME_EVENT: "IFRAME_EVENT"
});

const DEFAULT_STATE = Object.freeze({
  connected: false,
  publicKey: ""
});

async function getState() {
  const result = await chrome.storage.local.get(["connected", "publicKey"]);
  return {
    connected: Boolean(result.connected),
    publicKey: typeof result.publicKey === "string" ? result.publicKey : ""
  };
}

async function setState(next) {
  const update = {
    connected: Boolean(next.connected),
    publicKey: typeof next.publicKey === "string" ? next.publicKey : ""
  };
  await chrome.storage.local.set(update);
  return update;
}

function safeError(err) {
  if (!err) return "Unknown error";
  if (err instanceof Error) return `${err.name}: ${err.message}`;
  try {
    return JSON.stringify(err);
  } catch {
    return String(err);
  }
}

chrome.runtime.onInstalled.addListener(async () => {
  try {
    const existing = await chrome.storage.local.get(["connected", "publicKey"]);
    const hasAny = Object.prototype.hasOwnProperty.call(existing, "connected") ||
      Object.prototype.hasOwnProperty.call(existing, "publicKey");

    if (!hasAny) {
      await chrome.storage.local.set({ ...DEFAULT_STATE });
    }

    // Ensure the side panel is enabled and points to our page.
    if (chrome.sidePanel?.setOptions) {
      await chrome.sidePanel.setOptions({
        path: "sidepanel.html",
        enabled: true
      });
    }
  } catch (e) {
    console.warn("[DeFi Co-Pilot] onInstalled error:", safeError(e));
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    try {
      if (!message || typeof message !== "object") {
        sendResponse({ ok: false, error: "Invalid message" });
        return;
      }

      const { type, payload } = message;

      switch (type) {
        case MessageType.GET_STATE: {
          const state = await getState();
          sendResponse({ ok: true, state });
          return;
        }

        case MessageType.SET_PUBLIC_KEY: {
          const publicKey = payload?.publicKey;
          if (typeof publicKey !== "string" || publicKey.trim().length < 10) {
            sendResponse({ ok: false, error: "Invalid publicKey" });
            return;
          }
          const state = await setState({ connected: true, publicKey: publicKey.trim() });
          sendResponse({ ok: true, state });
          return;
        }

        case MessageType.DISCONNECT: {
          const state = await setState({ connected: false, publicKey: "" });
          sendResponse({ ok: true, state });
          return;
        }

        case MessageType.OPEN_SIDEPANEL: {
          const tabId = payload?.tabId;

          // In many Chrome versions, sidePanel.open requires a tabId.
          if (typeof tabId !== "number") {
            sendResponse({ ok: false, error: "Missing tabId" });
            return;
          }

          if (!chrome.sidePanel?.open) {
            sendResponse({ ok: false, error: "sidePanel.open is not available" });
            return;
          }

          // Make sure side panel is enabled for this tab.
          if (chrome.sidePanel?.setOptions) {
            await chrome.sidePanel.setOptions({ tabId, path: "sidepanel.html", enabled: true });
          }

          try {
            await chrome.sidePanel.open({ tabId });
            sendResponse({ ok: true });
          } catch (e) {
            // Common in MV3: "sidePanel.open() may only be called in response to a user gesture."
            // This usually means the call originated from the service worker rather than the UI click.
            const msg = safeError(e);
            sendResponse({ ok: false, error: msg });
          }
          return;
        }

        case MessageType.IFRAME_EVENT: {
          // This is a generic forward from the side panel.
          // We do minimal validation and log safely.
          const origin = payload?.origin;
          const data = payload?.data;

          if (origin !== DAPP_ORIGIN) {
            sendResponse({ ok: false, error: "Blocked iframe origin" });
            return;
          }

          console.log("[DeFi Co-Pilot] IFRAME_EVENT:", {
            from: origin,
            data,
            senderUrl: sender?.url || null
          });

          // If the page-context wallet bridge returns a successful publicKey,
          // persist it so the extension can treat it as "connected".
          if (
            data &&
            typeof data === "object" &&
            data.type === "INPAGE_WALLET_RESULT" &&
            data.result &&
            typeof data.result === "object" &&
            data.result.ok === true &&
            typeof data.result.publicKey === "string" &&
            data.result.publicKey.trim().length > 10
          ) {
            await setState({ connected: true, publicKey: data.result.publicKey.trim() });
          }

          sendResponse({ ok: true });
          return;
        }

        default:
          sendResponse({ ok: false, error: `Unknown message type: ${String(type)}` });
      }
    } catch (e) {
      console.warn("[DeFi Co-Pilot] message handler error:", safeError(e));
      sendResponse({ ok: false, error: safeError(e) });
    }
  })();

  // Keep the message channel open for async responses.
  return true;
});
