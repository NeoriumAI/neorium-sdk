const DAPP_URL = "https://v0-de-fi-co-pilot-ui.vercel.app";
const DAPP_ORIGIN = "https://v0-de-fi-co-pilot-ui.vercel.app";

function $(id) {
  return document.getElementById(id);
}

function showFallback(debugText) {
  $("fallback").hidden = false;
  $("frameWrap").style.display = "none";
  $("debugText").textContent = debugText || "";
}

function showFrame() {
  $("fallback").hidden = true;
  $("frameWrap").style.display = "block";
  $("debugText").textContent = "";
}

function buildDebugInfo(reason) {
  return [
    `reason: ${reason}`,
    `dappUrl: ${DAPP_URL}`,
    `time: ${new Date().toISOString()}`,
    `ua: ${navigator.userAgent}`,
    "",
    "Hints:",
    "- If the site sends X-Frame-Options: DENY/SAMEORIGIN, it cannot be embedded.",
    "- If the site sends CSP frame-ancestors 'none', it cannot be embedded."
  ].join("\n");
}

function mountIframe() {
  const frame = $("dappFrame");

  showFrame();

  let didLoad = false;
  const startedAt = Date.now();

  frame.addEventListener(
    "load",
    () => {
      didLoad = true;
      showFrame();
      requestProviderStatus();
    },
    { once: true }
  );

  // Note: iframe "error" events are not reliable across all cases.
  frame.addEventListener(
    "error",
    () => {
      showFallback(buildDebugInfo("iframe error event"));
    },
    { once: true }
  );

  frame.src = DAPP_URL;

  // Timeout fallback for common embed blocks.
  window.setTimeout(() => {
    if (didLoad) return;
    const elapsed = Date.now() - startedAt;
    showFallback(buildDebugInfo(`iframe load timeout (${elapsed}ms)`));
  }, 10000);
}

function requestProviderStatus() {
  const frame = $("dappFrame");
  if (!frame?.contentWindow) return;
  const requestId = `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  frame.contentWindow.postMessage({ type: "EXT_GET_PROVIDER_STATUS", requestId }, DAPP_ORIGIN);
}

async function openSidePanel() {
  // IMPORTANT:
  // chrome.sidePanel.open() requires a user gesture.
  // Calling it inside the service worker (via messaging) can lose the gesture
  // and trigger: "may only be called in response to a user gesture".
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs && tabs.length ? tabs[0] : null;
    const tabId = typeof tab?.id === "number" ? tab.id : null;
    if (tabId == null) return;

    // Ensure side panel is enabled for this tab.
    if (chrome.sidePanel?.setOptions) {
      chrome.sidePanel.setOptions({ tabId, path: "sidepanel.html", enabled: true }).catch(() => {});
    }

    if (chrome.sidePanel?.open) {
      chrome.sidePanel.open({ tabId }).catch(() => {
        // If it still fails, do nothing (no fallback UI requested).
      });
    }
  });
}

function tryConnectViaExistingDappTab(requestId) {
  const pattern = `${DAPP_URL}/*`;
  chrome.tabs.query({ url: pattern }, (tabs) => {
    const tab = Array.isArray(tabs) && tabs.length ? tabs[0] : null;
    const tabId = typeof tab?.id === "number" ? tab.id : null;
    if (tabId == null) {
      showToast(
        "Wallet tidak tersedia di iframe",
        "Solusi tanpa buka tab/window baru: buka DApp di tab Chrome biasa dulu, lalu klik Connect lagi."
      );
      return;
    }

    chrome.tabs.sendMessage(tabId, { type: "CS_CONNECT_WALLET", requestId: requestId || null }, () => {
      if (chrome.runtime.lastError) {
        showToast(
          "Tidak bisa trigger connect",
          "Pastikan tab DApp sudah terbuka dan extension direload."
        );
      } else {
        showToast("Trigger connect via tab DApp", "Silakan cek popup Phantom/Solflare.");
      }
    });
  });
}

let toastEl = null;
let toastTimer = null;

function showToast(title, detail) {
  if (!toastEl) {
    toastEl = document.createElement("div");
    toastEl.className = "toast";
    document.querySelector(".app")?.appendChild(toastEl);
  }

  toastEl.innerHTML = `
    <div>${title}</div>
    ${detail ? `<div class="muted">${detail}</div>` : ""}
  `;

  if (toastTimer) window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => {
    if (toastEl) toastEl.remove();
    toastEl = null;
    toastTimer = null;
  }, 6000);
}

document.addEventListener("DOMContentLoaded", () => {
  $("openSidePanelBtn")?.addEventListener("click", openSidePanel);
  mountIframe();

  // Show wallet-connect errors coming back from the inpage bridge.
  chrome.runtime.onMessage.addListener((message) => {
    if (!message || typeof message !== "object") return;
    if (message.type !== "IFRAME_EVENT") return;

    const data = message.payload?.data;
    if (!data || typeof data !== "object") return;
    if (data.type !== "INPAGE_WALLET_RESULT") return;

    if (data.result?.ok === true) return;

    const err = typeof data.result?.error === "string" ? data.result.error : "Wallet connect failed";
    const details = data.result?.details;
    const hasProvider = details?.hasProvider === true;
    const isIframe = details?.isIframe === true;

    if (!hasProvider && isIframe) {
      // No new tab/window: best-effort trigger connect via an already-open DApp tab.
      tryConnectViaExistingDappTab(data.requestId || null);
    } else {
      showToast("Wallet connect failed", err);
    }
  });

  chrome.runtime.onMessage.addListener((message) => {
    if (!message || typeof message !== "object") return;
    if (message.type !== "IFRAME_EVENT") return;

    const data = message.payload?.data;
    if (!data || typeof data !== "object") return;
    if (data.type !== "INPAGE_PROVIDER_STATUS") return;

    const info = data.result?.info;
    if (!info || typeof info !== "object") return;

    const hasProvider = info.hasProvider === true;
    const isIframe = info.isIframe === true;
    const isConnected = info.isConnected === true;
    const isPhantom = info.providerFlags?.isPhantom === true;
    const isSolflare = info.providerFlags?.isSolflare === true;

    if (hasProvider && isIframe && !isConnected) {
      const name = isPhantom ? "Phantom" : isSolflare ? "Solflare" : "Wallet";
      showToast(`${name} detected`, "Connect from within the embedded DApp.");
      return;
    }

    if (!hasProvider && isIframe) {
      showToast(
        "Wallet tidak terdeteksi di iframe",
        "Jika kamu sudah install Phantom/Solflare, biasanya provider tidak muncul di iframe. Buka DApp di tab biasa (tanpa dibuat otomatis), lalu klik Connect."
      );
    }
  });
});
