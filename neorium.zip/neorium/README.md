# DeFi Co-Pilot (Solana Only)

Chrome Extension (Manifest V3) with **Popup + Side Panel + Messaging**.

Primary goal: embed the DeFi utility DApp inside the extension via an iframe:

- https://v0-de-fi-co-pilot-ui.vercel.app

## Features

- Popup UI
  - “Ready” status
  - Open Side Panel
  - Open DApp in a new tab
  - Demo wallet connect/disconnect (stores a dummy Solana publicKey)
- Side Panel UI
  - Full-height iframe embed
  - Robust fallback UI if the iframe fails to load
  - PostMessage bridge with strict origin checks
- Background service worker
  - Central message router
  - Session state in `chrome.storage.local` (`connected`, `publicKey`)

## Load Unpacked (Chrome)

1. Open Chrome and go to: `chrome://extensions`
2. Enable **Developer mode** (top-right)
3. Click **Load unpacked**
4. Select this folder (the one containing `manifest.json`)

## How to Open the Side Panel

- Click the extension icon to open the popup
- Click **Open Side Panel**

Notes:
- Some Chrome versions require an active tab id for `chrome.sidePanel.open(...)`. This extension requests `tabs` permission and uses the current active tab id.

## Iframe / CSP Issues (Common)

If the side panel shows the fallback “Unable to load DApp in iframe”, it’s usually one of:

1. **The site blocks embedding**
   - `X-Frame-Options: DENY` or `SAMEORIGIN`
   - CSP: `frame-ancestors 'none'` (or doesn’t include the extension origin)

   If the site blocks embedding, **no extension change can force it**. You must change the site’s headers.

2. **Network / DNS / SSL issues**

3. **Host permissions mismatch**
   - Make sure `manifest.json` includes the correct `host_permissions` for the DApp URL.

### If you think “Vercel is blocking”

Vercel itself usually isn’t the blocker — iframe embedding is blocked by **response headers** from your app:

- `X-Frame-Options: DENY` or `SAMEORIGIN`
- `Content-Security-Policy: frame-ancestors ...`

If you control the DApp (Next.js on Vercel), you can allow embedding by adjusting headers.

**Next.js (`next.config.js`) example:**

```js
// next.config.js
module.exports = {
  async headers() {
    return [
      {
        source: "/(.*)",
        headers: [
          // Remove X-Frame-Options if you set it anywhere.
          // And configure CSP frame-ancestors to include your extension origin.
          {
            key: "Content-Security-Policy",
            value: "frame-ancestors 'self' chrome-extension:" // relax carefully
          }
        ]
      }
    ];
  }
};
```

Notes:
- For production, it’s safer to whitelist your specific extension ID (Chrome Web Store ID). For unpacked dev builds, the extension ID can vary.
- Be careful: loosening `frame-ancestors` can increase clickjacking risk.

### Extension CSP Notes

This project uses a strict extension-pages CSP:

- `script-src 'self'` (no inline scripts)
- `object-src 'self'`
- `frame-src https://v0-de-fi-co-pilot-ui.vercel.app`
- `child-src https://v0-de-fi-co-pilot-ui.vercel.app`

No `unsafe-eval` is used.

## Update host_permissions for another Vercel URL

In `manifest.json`, change:

- `host_permissions`: update the allowed URL pattern
- `content_security_policy.extension_pages`: update `frame-src` to match the new origin

Example:

- `https://my-new-app.vercel.app/*`

## Wallet Connection (Demo Only)

The popup includes a **Connect (Demo)** button that stores a dummy Solana publicKey.

Security notes:
- **Never store private keys** in extension storage.
- **Never request seed phrases**.

### How to Replace Demo With Real Solana Wallet Integration

You generally have two approaches:

**Option A — Use `window.solana` inside the embedded DApp**
- If the embedded DApp runs in a normal browser context and the user has a wallet like Phantom installed, the DApp can use `window.solana` directly.
- This is usually the simplest approach.
- Caveat: wallets may restrict access depending on iframe context / permissions.

**Option B — Extension-provided inpage provider (advanced)**
- Use a content script + page-injected script to expose a provider API.
- Forward RPC requests through `chrome.runtime.sendMessage` to the service worker.
- This is more work, but gives you control over the provider surface.

## Development

### Important: keep `node_modules` out of the extension folder

Chrome loads an unpacked extension by scanning everything inside the extension directory. If you keep a full Next.js project with `node_modules` under this folder, Chrome may warn about accidentally packaged private keys (e.g. test PEM files from dependencies) and the extension becomes unnecessarily large.

Recommended workflow:
- Keep the full Next.js source in `dapp-src/` for reference.
- Use `dapp-export-src/` only as an export/build copy.
- After building, remove `node_modules` from both folders (or move these folders outside the extension root) and keep only `app/` as the runtime bundle.

- No external libraries
- Edit files and click “Reload” in `chrome://extensions`

## Troubleshooting

- Open DevTools:
  - Popup: right-click popup → Inspect
  - Side panel: open side panel → right-click → Inspect
  - Service worker: `chrome://extensions` → extension → Service worker → Inspect
