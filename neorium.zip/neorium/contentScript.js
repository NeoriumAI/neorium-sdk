// Runs on https://v0-de-fi-co-pilot-ui.vercel.app/* (including iframes)
// Bridges Extension UI -> Page context so we can attempt calling window.solana.

const DAPP_ORIGIN = "https://v0-de-fi-co-pilot-ui.vercel.app";

let overlayEl = null;

function hideOverlay() {
  if (overlayEl) {
    overlayEl.remove();
    overlayEl = null;
  }
}

function showOverlayButton(requestId) {
  // Minimal, unobtrusive overlay.
  // This provides a direct user gesture within the PAGE context, which some wallets require.
  // Works inside the embedded iframe (side panel/popup) too.
  if (overlayEl) return;

  overlayEl = document.createElement("div");
  overlayEl.style.position = "fixed";
  overlayEl.style.right = "12px";
  overlayEl.style.bottom = "12px";
  overlayEl.style.zIndex = "2147483647";
  overlayEl.style.fontFamily = "system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial";

  const btn = document.createElement("button");
  btn.textContent = "Connect wallet";
  btn.style.border = "1px solid #000";
  btn.style.background = "#000";
  btn.style.color = "#fff";
  btn.style.borderRadius = "10px";
  btn.style.padding = "10px 12px";
  btn.style.fontSize = "12px";
  btn.style.cursor = "pointer";

  btn.addEventListener("click", () => {
    ensureInpageInjected();
    window.postMessage(
      { type: "INPAGE_CONNECT_WALLET", requestId: requestId || null },
      DAPP_ORIGIN
    );
  });

  const hint = document.createElement("div");
  hint.textContent = "Click to trigger Phantom/Solflare connect.";
  hint.style.marginTop = "6px";
  hint.style.fontSize = "11px";
  hint.style.color = "#000";
  hint.style.background = "#fff";
  hint.style.border = "1px solid #e6e6e6";
  hint.style.borderRadius = "10px";
  hint.style.padding = "8px 10px";

  overlayEl.appendChild(btn);
  overlayEl.appendChild(hint);
  document.documentElement.appendChild(overlayEl);
}

let inpageInjected = false;

function ensureInpageInjected() {
  if (inpageInjected) return;
  inpageInjected = true;

  const script = document.createElement("script");
  script.src = chrome.runtime.getURL("inpage.js");
  script.async = false;
  (document.documentElement || document.head || document.body).appendChild(script);
}

// Allow extension pages/service worker to trigger a connect attempt in this tab.
// This is the most reliable way to hit Phantom/Solflare, because many wallets
// do NOT inject providers into third-party iframes.
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg !== "object") return;
  if (msg.type !== "CS_CONNECT_WALLET") return;

  try {
    hideOverlay();
    ensureInpageInjected();
    window.postMessage(
      { type: "INPAGE_CONNECT_WALLET", requestId: msg.requestId || null },
      DAPP_ORIGIN
    );
    sendResponse?.({ ok: true });
  } catch (e) {
    sendResponse?.({ ok: false, error: e instanceof Error ? e.message : String(e) });
  }

  return true;
});

// Listen for messages from the extension page (popup/sidepanel) targeting this frame.
window.addEventListener("message", (event) => {
  // Only accept messages sent from an extension page into this frame.
  if (typeof event.origin !== "string" || !event.origin.startsWith("chrome-extension://")) return;

  const msg = event.data;
  if (!msg || typeof msg !== "object") return;

  if (msg.type === "EXT_CONNECT_WALLET") {
    ensureInpageInjected();
    // Forward request to page context.
    window.postMessage(
      { type: "INPAGE_CONNECT_WALLET", requestId: msg.requestId || null },
      DAPP_ORIGIN
    );
  }

  if (msg.type === "EXT_GET_PROVIDER_STATUS") {
    ensureInpageInjected();
    window.postMessage(
      { type: "INPAGE_GET_PROVIDER_STATUS", requestId: msg.requestId || null },
      DAPP_ORIGIN
    );
  }
});

// Forward results from page context back to the service worker for logging/debug.
window.addEventListener("message", (event) => {
  if (event.origin !== DAPP_ORIGIN) return;

  const msg = event.data;
  if (!msg || typeof msg !== "object") return;

  if (msg.type === "INPAGE_WALLET_RESULT") {
    if (msg.result?.ok === true) {
      hideOverlay();
    } else {
      const err = typeof msg.result?.error === "string" ? msg.result.error : "";
      // If wallets require a user gesture or provider isn't available yet,
      // offer a click overlay inside the same frame.
      const low = err.toLowerCase();
      if (low.includes("user gesture") || low.includes("interaction") || low.includes("no window.solana")) {
        showOverlayButton(msg.requestId || null);
      }
    }

    chrome.runtime.sendMessage({
      type: "IFRAME_EVENT",
      payload: {
        origin: DAPP_ORIGIN,
        data: msg
      }
    });
  }

  if (msg.type === "INPAGE_PROVIDER_STATUS") {
    chrome.runtime.sendMessage({
      type: "IFRAME_EVENT",
      payload: {
        origin: DAPP_ORIGIN,
        data: msg
      }
    });
  }
});
