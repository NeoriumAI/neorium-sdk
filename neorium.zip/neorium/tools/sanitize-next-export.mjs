import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";

const EXT_ROOT = process.cwd();
const APP_DIR = path.join(EXT_ROOT, "app");
const INLINE_DIR = path.join(APP_DIR, "_inline");

function listHtmlFiles(dir) {
  const out = [];
  const stack = [dir];
  while (stack.length) {
    const cur = stack.pop();
    const entries = fs.readdirSync(cur, { withFileTypes: true });
    for (const ent of entries) {
      const full = path.join(cur, ent.name);
      if (ent.isDirectory()) {
        // Skip Next build assets.
        if (ent.name === "_next") continue;
        if (ent.name === "_inline") continue;
        stack.push(full);
      } else if (ent.isFile() && ent.name.endsWith(".html")) {
        out.push(full);
      }
    }
  }
  return out;
}

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function hashContent(content) {
  return crypto.createHash("sha256").update(content).digest("hex").slice(0, 16);
}

function sanitizeHtmlFile(filePath) {
  const original = fs.readFileSync(filePath, "utf8");

  // Match inline scripts that do NOT have a src attribute.
  // Captures attributes (ignored) + body.
  const re = /<script(?![^>]*\ssrc=)([^>]*)>([\s\S]*?)<\/script>/gi;

  let didChange = false;
  let match;
  let next = original;

  // We rebuild progressively to preserve order.
  // Use a loop with index-based replace to avoid double-processing.
  let offset = 0;
  const pieces = [];

  while ((match = re.exec(original)) !== null) {
    const start = match.index;
    const end = re.lastIndex;
    const attrs = match[1] || "";
    const body = match[2] || "";

    // If the script is explicitly non-executable JSON/LD, leave it alone.
    if (/\stype\s*=\s*['\"]application\/ld\+json['\"]/i.test(attrs)) {
      continue;
    }

    didChange = true;
    pieces.push(original.slice(offset, start));

    const trimmedBody = body.trim();
    const name = `inline-${hashContent(trimmedBody || body)}.js`;
    const outPath = path.join(INLINE_DIR, name);

    // Write file only if it doesn't exist (dedupe).
    if (!fs.existsSync(outPath)) {
      fs.writeFileSync(outPath, body, "utf8");
    }

    // Use absolute path under /app so nested pages can reference it.
    pieces.push(`<script src="/app/_inline/${name}"></script>`);

    offset = end;
  }

  if (!didChange) return { filePath, changed: false, extracted: 0 };

  pieces.push(original.slice(offset));
  next = pieces.join("");

  fs.writeFileSync(filePath, next, "utf8");

  // Count remaining inline scripts for sanity.
  const remaining = (next.match(re) || []).length;
  return { filePath, changed: true, remainingInline: remaining };
}

function main() {
  if (!fs.existsSync(APP_DIR)) {
    console.error("Missing app/ directory. Run export copy first.");
    process.exit(1);
  }

  ensureDir(INLINE_DIR);

  const htmlFiles = listHtmlFiles(APP_DIR);
  let changedCount = 0;

  for (const f of htmlFiles) {
    const res = sanitizeHtmlFile(f);
    if (res.changed) changedCount += 1;
  }

  console.log(`Sanitized ${changedCount}/${htmlFiles.length} HTML files. Inline scripts extracted to app/_inline/.`);
}

main();
