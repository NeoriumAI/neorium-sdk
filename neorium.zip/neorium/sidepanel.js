const DAPP_ORIGIN = "https://v0-de-fi-co-pilot-ui.vercel.app";
const DAPP_URL = "https://v0-de-fi-co-pilot-ui.vercel.app";

const MessageType = Object.freeze({
  GET_STATE: "GET_STATE",
  SET_PUBLIC_KEY: "SET_PUBLIC_KEY",
  DISCONNECT: "DISCONNECT",
  OPEN_SIDEPANEL: "OPEN_SIDEPANEL",
  IFRAME_EVENT: "IFRAME_EVENT"
});

function $(id) {
  return document.getElementById(id);
}

async function sendMessage(message) {
  return await chrome.runtime.sendMessage(message);
}

function setConnectionUI(connected) {
  const dot = $("connDot");
  const text = $("connText");

  if (connected) {
    dot.style.opacity = "1";
    text.textContent = "Connected";
  } else {
    dot.style.opacity = "0.2";
    text.textContent = "Connect";
  }
}

function showFallback(debugText) {
  $("fallback").hidden = false;
  $("frameWrap").style.display = "none";
  $("debugText").textContent = debugText || "";
}

function showFrame() {
  $("fallback").hidden = true;
  $("frameWrap").style.display = "block";
  $("debugText").textContent = "";
}

function buildDebugInfo(reason) {
  return [
    `reason: ${reason}`,
    `dappUrl: ${DAPP_URL}`,
    `dappOrigin: ${DAPP_ORIGIN}`,
    `time: ${new Date().toISOString()}`,
    `ua: ${navigator.userAgent}`,
    "",
    "Hints:",
    "- If the site sends X-Frame-Options: DENY/SAMEORIGIN, it cannot be embedded.",
    "- If the site sends CSP frame-ancestors 'none', it cannot be embedded.",
    "- Check DevTools > Console for iframe errors."
  ].join("\n");
}

async function refreshStateAndBroadcast() {
  const res = await sendMessage({ type: MessageType.GET_STATE });
  const state = res?.ok ? res.state : null;
  setConnectionUI(Boolean(state?.connected));

  // Broadcast state to iframe so the embedded app can optionally react.
  const frame = $("dappFrame");
  if (frame?.contentWindow) {
    frame.contentWindow.postMessage(
      {
        type: "EXTENSION_STATE",
        payload: {
          connected: Boolean(state?.connected),
          publicKey: typeof state?.publicKey === "string" ? state.publicKey : ""
        }
      },
      DAPP_ORIGIN
    );
  }
}

function requestProviderStatus() {
  const frame = $("dappFrame");
  if (!frame?.contentWindow) return;
  const requestId = `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  frame.contentWindow.postMessage({ type: "EXT_GET_PROVIDER_STATUS", requestId }, DAPP_ORIGIN);
}

function setupPostMessageBridge() {
  const frame = $("dappFrame");

  window.addEventListener("message", async (event) => {
    // Strict origin check: only accept messages from the embedded DApp.
    if (event.origin !== DAPP_ORIGIN) return;

    // Optional: ensure it comes from our iframe.
    if (frame?.contentWindow && event.source !== frame.contentWindow) return;

    // Forward to service worker.
    await sendMessage({
      type: MessageType.IFRAME_EVENT,
      payload: {
        origin: event.origin,
        data: event.data
      }
    });

    // If the DApp asks for state, answer directly.
    if (event.data && typeof event.data === "object" && event.data.type === "REQUEST_EXTENSION_STATE") {
      await refreshStateAndBroadcast();
    }
  });
}

function mountIframe() {
  const frame = $("dappFrame");

  // Reset UI
  showFrame();

  let didLoad = false;
  const startedAt = Date.now();

  const onLoad = async () => {
    didLoad = true;
    showFrame();
    await refreshStateAndBroadcast();
    requestProviderStatus();
  };

  frame.addEventListener("load", onLoad, { once: true });

  // Note: iframe "error" events are not reliable across all cases.
  frame.addEventListener(
    "error",
    () => {
      showFallback(buildDebugInfo("iframe error event"));
    },
    { once: true }
  );

  frame.src = DAPP_URL;

  // Timeout-based fallback for common embed blocks.
  window.setTimeout(() => {
    if (didLoad) return;
    const elapsed = Date.now() - startedAt;
    showFallback(buildDebugInfo(`iframe load timeout (${elapsed}ms)`));
  }, 12000);
}

function tryConnectViaExistingDappTab(requestId) {
  const pattern = `${DAPP_URL}/*`;
  chrome.tabs.query({ url: pattern }, (tabs) => {
    const tab = Array.isArray(tabs) && tabs.length ? tabs[0] : null;
    const tabId = typeof tab?.id === "number" ? tab.id : null;
    if (tabId == null) {
      showToast(
        "Wallet tidak tersedia di iframe",
        "Solusi tanpa buka tab/window baru: buka DApp di tab Chrome biasa dulu, lalu klik Connect lagi."
      );
      return;
    }

    chrome.tabs.sendMessage(tabId, { type: "CS_CONNECT_WALLET", requestId: requestId || null }, () => {
      if (chrome.runtime.lastError) {
        showToast(
          "Tidak bisa trigger connect",
          "Pastikan tab DApp sudah terbuka dan extension direload."
        );
      } else {
        showToast("Trigger connect via tab DApp", "Silakan cek popup Phantom/Solflare.");
      }
    });
  });
}

let toastEl = null;
let toastTimer = null;

function showToast(title, detail) {
  const root = document.querySelector(".main") || document.querySelector(".app") || document.body;
  if (!toastEl) {
    toastEl = document.createElement("div");
    toastEl.className = "toast";
    root.appendChild(toastEl);
  }

  toastEl.innerHTML = `
    <div>${title}</div>
    ${detail ? `<div class="muted">${detail}</div>` : ""}
  `;

  if (toastTimer) window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => {
    if (toastEl) toastEl.remove();
    toastEl = null;
    toastTimer = null;
  }, 6000);
}

document.addEventListener("DOMContentLoaded", async () => {
  $("retryBtn").addEventListener("click", () => {
    // Recreate iframe load event by resetting src.
    const frame = $("dappFrame");
    frame.src = "about:blank";
    window.setTimeout(mountIframe, 50);
  });

  setupPostMessageBridge();
  mountIframe();

  chrome.runtime.onMessage.addListener((message) => {
    if (!message || typeof message !== "object") return;
    if (message.type !== "IFRAME_EVENT") return;

    const data = message.payload?.data;
    if (!data || typeof data !== "object") return;
    if (data.type !== "INPAGE_WALLET_RESULT") return;

    if (data.result?.ok === true) return;

    const err = typeof data.result?.error === "string" ? data.result.error : "Wallet connect failed";
    const details = data.result?.details;
    const hasProvider = details?.hasProvider === true;
    const isIframe = details?.isIframe === true;

    if (!hasProvider && isIframe) {
      tryConnectViaExistingDappTab(data.requestId || null);
    } else {
      showToast("Wallet connect failed", err);
    }
  });

  chrome.runtime.onMessage.addListener((message) => {
    if (!message || typeof message !== "object") return;
    if (message.type !== "IFRAME_EVENT") return;

    const data = message.payload?.data;
    if (!data || typeof data !== "object") return;
    if (data.type !== "INPAGE_PROVIDER_STATUS") return;

    const info = data.result?.info;
    if (!info || typeof info !== "object") return;

    const hasProvider = info.hasProvider === true;
    const isIframe = info.isIframe === true;
    const isConnected = info.isConnected === true;
    const isPhantom = info.providerFlags?.isPhantom === true;
    const isSolflare = info.providerFlags?.isSolflare === true;

    if (hasProvider && isIframe && !isConnected) {
      const name = isPhantom ? "Phantom" : isSolflare ? "Solflare" : "Wallet";
      showToast(`${name} detected`, "Connect from within the embedded DApp.");
      return;
    }

    if (!hasProvider && isIframe) {
      showToast(
        "Wallet tidak terdeteksi di iframe",
        "Jika kamu sudah install Phantom/Solflare, biasanya provider tidak muncul di iframe. Buka DApp di tab biasa (tanpa dibuat otomatis), lalu klik Connect."
      );
    }
  });
});
