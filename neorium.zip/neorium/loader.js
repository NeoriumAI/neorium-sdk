// Minimal loader to run the bundled DApp directly (no iframe).
// Must be an external script to satisfy MV3 CSP (no inline scripts).

(() => {
  const target = chrome.runtime.getURL("app/index-shell.html");
  // Use replace() so Back doesn't return to loader.
  location.replace(target);
})();
