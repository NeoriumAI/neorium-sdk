// Runs in the PAGE context of https://v0-de-fi-co-pilot-ui.vercel.app
// This is injected by contentScript.js so it can access window.solana (wallet providers).

(function () {
  const DAPP_ORIGIN = "https://v0-de-fi-co-pilot-ui.vercel.app";

  function getProviderCandidate() {
    const fromSolana = window.solana;
    const fromPhantom = window.phantom?.solana;
    const fromSolflare = window.solflare?.solana;

    // Prefer explicit wallet namespaces if present.
    const provider = fromPhantom || fromSolflare || fromSolana;

    const isPhantom = Boolean(provider?.isPhantom || fromPhantom?.isPhantom);
    const isSolflare = Boolean(provider?.isSolflare || fromSolflare?.isSolflare);
    const hasConnect = typeof provider?.connect === "function";
    const isConnected = Boolean(provider?.isConnected);

    return {
      provider,
      info: {
        hasProvider: Boolean(provider),
        providerFlags: {
          isPhantom,
          isSolflare
        },
        hasConnect,
        isConnected,
        isTopLevel: window.top === window,
        isIframe: window.top !== window,
        href: String(location.href)
      }
    };
  }

  async function connectSolana() {
    const { provider } = getProviderCandidate();
    if (!provider) throw new Error("No wallet provider found (Phantom/Solflare may not inject into iframes).");

    if (typeof provider.connect !== "function") {
      throw new Error("window.solana.connect is not a function.");
    }

    const res = await provider.connect();

    // Phantom typically returns { publicKey }, but keep it generic.
    return {
      ok: true,
      publicKey: res?.publicKey ? String(res.publicKey) : null
    };
  }

  window.addEventListener("message", async (event) => {
    if (event.origin !== DAPP_ORIGIN) return;

    const msg = event.data;
    if (!msg || typeof msg !== "object") return;

    if (msg.type === "INPAGE_GET_PROVIDER_STATUS") {
      const { info } = getProviderCandidate();
      window.postMessage(
        { type: "INPAGE_PROVIDER_STATUS", requestId: msg.requestId || null, result: { ok: true, info } },
        DAPP_ORIGIN
      );
      return;
    }

    if (msg.type !== "INPAGE_CONNECT_WALLET") return;

    try {
      const result = await connectSolana();
      window.postMessage(
        { type: "INPAGE_WALLET_RESULT", requestId: msg.requestId || null, result },
        DAPP_ORIGIN
      );
    } catch (e) {
      const details = getProviderCandidate().info;

      window.postMessage(
        {
          type: "INPAGE_WALLET_RESULT",
          requestId: msg.requestId || null,
          result: { ok: false, error: e instanceof Error ? e.message : String(e), details }
        },
        DAPP_ORIGIN
      );
    }
  });
})();
