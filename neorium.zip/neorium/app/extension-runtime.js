// Extension runtime shim for static-exported Next.js.
// Rewrites relative API calls ("/api/... ") to the original Vercel deployment.
// This keeps the exported app functional even though Next Route Handlers can't run in static export.

(() => {
  const API_ORIGIN = "https://v0-de-fi-co-pilot-ui.vercel.app";

  const originalFetch = window.fetch.bind(window);

  window.fetch = (input, init) => {
    try {
      if (typeof input === "string" && input.startsWith("/api/")) {
        return originalFetch(`${API_ORIGIN}${input}`, init);
      }
      if (input instanceof Request) {
        const url = input.url;
        // Only rewrite same-origin /api calls.
        if (url.startsWith(location.origin + "/api/")) {
          const nextUrl = API_ORIGIN + url.substring(location.origin.length);
          const nextReq = new Request(nextUrl, input);
          return originalFetch(nextReq);
        }
      }
    } catch {
      // no-op
    }
    return originalFetch(input, init);
  };
})();
