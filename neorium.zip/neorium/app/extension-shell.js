// Injects minimal extension controls into the bundled app.
// Kept separate from the app build so we don't need to modify the Next.js source.

(async () => {
  const isExtensionPage = typeof chrome !== "undefined" && !!chrome.runtime?.id;
  if (!isExtensionPage) return;

  const canOpenSidePanel = !!chrome.sidePanel?.open && !!chrome.windows?.getCurrent;
  if (!canOpenSidePanel) return;

  // Avoid double-injection.
  if (document.getElementById("neorium-open-sidepanel")) return;

  const button = document.createElement("button");
  button.id = "neorium-open-sidepanel";
  button.type = "button";
  button.textContent = "Side panel";
  button.setAttribute("aria-label", "Open side panel");

  button.addEventListener("click", async () => {
    try {
      const currentWindow = await chrome.windows.getCurrent();
      if (!currentWindow?.id) return;
      await chrome.sidePanel.open({ windowId: currentWindow.id });
    } catch {
      // Intentionally silent; the popup is small and we avoid extra UI.
    }
  });

  document.documentElement.appendChild(button);
})();
